package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CustomerDTO;
import com.capstore.admin.model.UserDTO;
import com.capstore.admin.repository.UserRepository;


@RestController
@RequestMapping("api/v1/")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@RequestMapping(value = "login/users", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<UserDTO> list() {
		return userRepository.findAll();
	}

	@RequestMapping(value = "loginPage/adduser", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO create(@RequestBody UserDTO customerDTO) {
		return userRepository.saveAndFlush(customerDTO);
	}

	@RequestMapping(value = "loginPage/findUserById/{id}", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO get(@PathVariable Integer id) {
		return userRepository.findOne(id);
	}

	@RequestMapping(value = "loginPage/UpdateUserById/{id}", method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO update(@PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
		UserDTO existingUser = userRepository.findOne(id);
		BeanUtils.copyProperties(customerDTO, existingUser);
		return userRepository.saveAndFlush(existingUser);
	}

	@RequestMapping(value = "loginPage/DeleteUserById/{id}", method = RequestMethod.DELETE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO delete(@PathVariable Integer id) {
		UserDTO existingUser = userRepository.findOne(id);
		userRepository.delete(existingUser);
		return existingUser;
	}
	
	
	
}
