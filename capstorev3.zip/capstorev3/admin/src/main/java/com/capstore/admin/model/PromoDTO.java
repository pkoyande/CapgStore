package com.capstore.admin.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="promo")
public class PromoDTO {

	@Id
	@Column(name="promocode")
	private String promoCode;
	private int discountoffered;
	private Date promovalidity;
	private String softdelete;
	
	public String getPromoCode() 
	{
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getDiscountOffered() {
		return discountoffered;
	}
	public void setDiscountOffered(int discountOffered) {
		this.discountoffered = discountOffered;
	}
	public Date getPromoValidity() {
		return promovalidity;
	}
	public void setPromoValidity(Date promoValidity) {
		this.promovalidity = promoValidity;
	}
	public String getSoftdelete() {
		return softdelete;
	}
	public void setSoftdelete(String softdelete) {
		this.softdelete = softdelete;
	}
	
	
}
