package com.capstore.admin.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="returnrequest")
public class ReturnRequestDTO {

	
	@Id
	@Column(name="returnid")
	private int ReturnId;
	private int refundamount;
	private String returnstatus;
	private int customerid;
	private int productid;
	private int orderid;
	/*//@Id
	@OneToOne(targetEntity= CustomerDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="customerid", insertable=false, updatable=false)
	private CustomerDTO customer;
	//@Id
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="productid", insertable=false, updatable=false)
	private ProductDTO product;
	//@Id
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "orderid",insertable = false, updatable = false)
	private OrderDTO order;*/
	
	public int getRefundAmount() {
		return refundamount;
	}
	public void setRefundAmount(int refundAmount) {
		this.refundamount = refundAmount;
	}
	public String getReturnStatus() {
		return returnstatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnstatus = returnStatus;
	}
	/*public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public OrderDTO getOrder() {
		return order;
	}
	public void setOrder(OrderDTO order) {
		this.order = order;
	}*/
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	
	
}
