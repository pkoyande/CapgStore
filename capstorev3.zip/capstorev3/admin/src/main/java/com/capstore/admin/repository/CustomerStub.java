package com.capstore.admin.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capstore.admin.model.CustomerDTO;


public class CustomerStub {
	private static Map<Long, CustomerDTO> wrecks = new HashMap<Long, CustomerDTO>();
	private static Long idIndex = 3L;

	//populate initial wrecks
/*	static {
		CustomerDTO a = new CustomerDTO(1L, "U869", "A very deep German UBoat", "FAIR", 200, 44.12, 138.44, 1994);
		wrecks.put(1L, a);
		CustomerDTO b = new CustomerDTO(2L, "Thistlegorm", "British merchant boat in the Red Sea", "GOOD", 80, 44.12, 138.44, 1994);
		wrecks.put(2L, b);
		CustomerDTO c = new CustomerDTO(3L, "S.S. Yongala", "A luxury passenger ship wrecked on the great barrier reef", "FAIR", 50, 44.12, 138.44, 1994);
		wrecks.put(3L, c);
	}*/

	public static List<CustomerDTO> list() {
		return new ArrayList<CustomerDTO>(wrecks.values());
	}

	public static CustomerDTO create(CustomerDTO wreck) {
		idIndex += idIndex;
//		wreck.setId(idIndex);
		wrecks.put(idIndex, wreck);
		return wreck;
	}

	public static CustomerDTO get(Long id) {
		return wrecks.get(id);
	}

	public static CustomerDTO update(Long id, CustomerDTO wreck) {
		wrecks.put(id, wreck);
		return wreck;
	}

	public static CustomerDTO delete(Long id) {
		return wrecks.remove(id);
	}
}
