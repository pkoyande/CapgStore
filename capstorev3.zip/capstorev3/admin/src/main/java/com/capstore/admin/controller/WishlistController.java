package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.admin.model.WishlistDTO;
import com.capstore.admin.repository.WishlistRepository;

@RestController
@RequestMapping("api/v1/")
public class WishlistController {
	@Autowired
	private WishlistRepository wishlistRepository;
	
	
	@RequestMapping(value = "users/wishlist", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<WishlistDTO> list() {
		
		return wishlistRepository.findAll();
	}
	
	
	@RequestMapping(value = "users/addToWishlist", method = RequestMethod.POST)
	public WishlistDTO create(@RequestBody WishlistDTO wishlistDTO) {
		return wishlistRepository.saveAndFlush(wishlistDTO);
	}
}
