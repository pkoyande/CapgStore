package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CartDTO;
import com.capstore.admin.repository.CartRepository;

@RestController
@RequestMapping("api/v1/")
public class CartController {

	
	@Autowired
	private CartRepository cartRepository;
	
	
	@RequestMapping(value = "users/cart", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<CartDTO> list() {
		
		return cartRepository.findAll();
	}
	
	
	@RequestMapping(value = "users/addToCart", method = RequestMethod.POST)
	public CartDTO create(@RequestBody CartDTO cartDTO) {
		return cartRepository.saveAndFlush(cartDTO);
	}
	
	
	
}
