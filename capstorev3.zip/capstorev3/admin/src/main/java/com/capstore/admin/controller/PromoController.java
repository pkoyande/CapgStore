package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.capstore.admin.model.PromoDTO;

import com.capstore.admin.repository.PromoRepository;

@RestController
@RequestMapping("api/v1/")
public class PromoController {
	
	@Autowired
	private PromoRepository promoRepository;

	@RequestMapping(value = "adminPage/findAllPromo", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<PromoDTO> list() {
		return promoRepository.findAll();
	}

	@RequestMapping(value = "adminPage/addPromo", method = RequestMethod.POST)
	public PromoDTO create(@RequestBody PromoDTO promoDTO) {
		return promoRepository.saveAndFlush(promoDTO);
	}
}
