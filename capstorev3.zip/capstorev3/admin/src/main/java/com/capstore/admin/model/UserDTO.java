package com.capstore.admin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class UserDTO {

	@Id
	@Column(name="emailid")
	private String email;
	private String password1;
	private String role;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password1;
	}

	public UserDTO(){
		
	}
	
	public UserDTO(String email, String password1, String role) {
		super();
		this.email = email;
		this.password1 = password1;
		this.role = role;
	}
	public void setPassword(String password) {
		this.password1 = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
}
