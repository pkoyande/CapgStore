package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.capstore.admin.model.UserDTO;


public interface UserRepository extends JpaRepository<UserDTO, Integer>{

}