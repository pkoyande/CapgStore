package com.cg.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.model.CustomerDTO;



public interface CustomerRepository extends  JpaRepository<CustomerDTO, Integer> {
	
	/* @Query
	 * (value = "SELECT * FROM CART WHERE CUSTOMERID = ?1", nativeQuery = true)
	 CustomerDTO getCustomerId(int customerId);*/
	 
	 
	 
	 
	 
}
