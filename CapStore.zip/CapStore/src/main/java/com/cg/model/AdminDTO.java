package com.cg.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="admindetail")
public class AdminDTO {

	@Id
	@Column(name="adminid")
	private int adminId;
	@Column(name="adminname")
	private String adminName;
	@Column(name="adminemail")
	private String email;
	@Column(name="mobileno")
	private String mobileNo;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<PromoDTO> promos;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<ReturnRequestDTO> returnRequests;
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public List<PromoDTO> getPromos() {
		return promos;
	}
	public void setPromos(List<PromoDTO> promos) {
		this.promos = promos;
	}
	public List<ReturnRequestDTO> getReturnRequests() {
		return returnRequests;
	}
	public void setReturnRequests(List<ReturnRequestDTO> returnRequests) {
		this.returnRequests = returnRequests;
	}
	
	
	
	
}
