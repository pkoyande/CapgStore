package com.cg.model;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="merchantdetail")
public class MerchantDTO {

	@Id
	@Column(name="merchantid")
	private int merchantId;
	@Column(name="merchantname")
	private String merchantName;
	@Column(name="merchantemail")
	private String email;
	@Column(name="merchantaddress")
	private String address;
	@Column(name="storename")
	private String storeName;
	@Column(name="mobileno")
	private String mobileNo;
	@Column(name="merchantrating")
	private String merchantRating;
	@Column(name="merchantfeedback")
	private String merchantFeedback;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
	private List<ProductDTO> products;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchant")
	private List<OfferDTO> offers;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchant")
	private List<OrderDTO> orders;
	
	public List<ProductDTO> getProducts() {
		return products;
	}
	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	public List<OfferDTO> getOffers() {
		return offers;
	}
	public void setOffers(List<OfferDTO> offers) {
		this.offers = offers;
	}
	public List<OrderDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getMerchantRating() {
		return merchantRating;
	}
	public void setMerchantRating(String merchantRating) {
		this.merchantRating = merchantRating;
	}
	public String getMerchantFeedback() {
		return merchantFeedback;
	}
	public void setMerchantFeedback(String merchantFeedback) {
		this.merchantFeedback = merchantFeedback;
	}
	
	
}
