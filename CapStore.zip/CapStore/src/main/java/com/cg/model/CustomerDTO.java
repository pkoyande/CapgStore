package com.cg.model;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customerdetail")
public class CustomerDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="customerid")
	private int customerId;
	@Column(name="customername")
	private String customerName;
	@Column(name="customeremail")
	private String email;
	@Column(name="mobileno")
	private String mobileNo;
	@Column(name="address")
	private String address;
	@Column(name="pincode")
	private int pinCode;
	
	
	public CustomerDTO()
	{
		
	}
	
	public CustomerDTO(int customerId, String customerName, String email, String mobileNo, String address, int pinCode,
			List<OrderDTO> orders, WishlistDTO wishlist, CartDTO cart) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.address = address;
		this.pinCode = pinCode;
		this.orders = orders;
		this.wishlist = wishlist;
		this.cart = cart;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="customer")
	private List<OrderDTO> orders;
	
	@OneToOne(fetch = FetchType.LAZY)
	private WishlistDTO wishlist; 
	
	@OneToOne(fetch = FetchType.LAZY)
	private CartDTO cart;
	
	public int getCustomerId() {
		return customerId;
	}
	public List<OrderDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}
	public WishlistDTO getWishlist() {
		return wishlist;
	}
	public void setWishlist(WishlistDTO wishlist) {
		this.wishlist = wishlist;
	}
	public CartDTO getCart() {
		return cart;
	}
	public void setCart(CartDTO cart) {
		this.cart = cart;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	
	
}
