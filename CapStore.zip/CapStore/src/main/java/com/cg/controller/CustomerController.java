package com.cg.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.model.CustomerDTO;
import com.cg.repository.CustomerRepository;


//import com.boot.model.Shipwreck;
//import com.boot.repository.ShipwreckRepository;

@RestController
@RequestMapping("api/v1/")
public class CustomerController {
	
	@Autowired
	//private ShipwreckRepository shipwreckRepository;
	private CustomerRepository customerRepository;
	
	
	@RequestMapping(value = "customer", method = RequestMethod.GET)
	public List<CustomerDTO> list() {
		return customerRepository.findAll();
	}

	@RequestMapping(value = "customer", method = RequestMethod.POST)
	public CustomerDTO create(@RequestBody CustomerDTO customer) {
		return customerRepository.saveAndFlush(customer);
	}

	@RequestMapping(value = "customer/{customerId}", method = RequestMethod.GET)
	public CustomerDTO get(@PathVariable Integer id) {
		return customerRepository.findOne(id);
	}

	@RequestMapping(value = "customer/{customerId}", method = RequestMethod.PUT)
	public CustomerDTO update(@PathVariable Integer id, @RequestBody CustomerDTO customer) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		BeanUtils.copyProperties(customer, existingCustomer);
		return customerRepository.saveAndFlush(existingCustomer);
	}

	@RequestMapping(value = "customer/{customerId}", method = RequestMethod.DELETE)
	public CustomerDTO delete(@PathVariable Integer id) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		customerRepository.delete(existingCustomer);
		return existingCustomer;
	}
	

	
}
