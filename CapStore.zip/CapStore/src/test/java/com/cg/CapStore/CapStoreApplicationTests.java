package com.cg.CapStore;

import org.junit.Test;
import org.junit.runner.RunWith;

public class CapStoreApplicationTests {

	@Test
	public void contextLoads() {
	}

}

